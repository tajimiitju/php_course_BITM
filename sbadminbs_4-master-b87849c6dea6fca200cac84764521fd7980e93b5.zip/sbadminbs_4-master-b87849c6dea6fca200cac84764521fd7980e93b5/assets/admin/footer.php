
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="assets/admin/js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="assets/admin/js/bootstrap.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="assets/admin/js/plugins/morris/raphael.min.js"></script>
    <script src="assets/admin/js/plugins/morris/morris.min.js"></script>
    <script src="assets/admin/js/plugins/morris/morris-data.js"></script>

</body>

</html>
