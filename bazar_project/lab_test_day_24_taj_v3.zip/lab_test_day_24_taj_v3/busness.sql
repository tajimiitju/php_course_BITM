-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2017 at 08:16 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `php-63`
--

-- --------------------------------------------------------

--
-- Table structure for table `busness`
--

CREATE TABLE `busness` (
  `id` int(11) NOT NULL,
  `Product_title` varchar(333) NOT NULL,
  `Product_price` decimal(33,0) NOT NULL,
  `Category` varchar(333) NOT NULL,
  `Description` varchar(333) NOT NULL,
  `image` varchar(3333) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `busness`
--

INSERT INTO `busness` (`id`, `Product_title`, `Product_price`, `Category`, `Description`, `image`) VALUES
(3, 'cghkjf', '43', 'Baby', '234t23twef', 'e (39).jpg'),
(4, 'xfgnxfgzdhgd', '333', 'Female', 'srthsrth', 'e (4).png'),
(5, 'dfhdfh', '99', 'Female', 'aetgew', 'Google2.jpg'),
(6, 'cccc', '333', 'Male', 'serg aeg aew', 'e (35).jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `busness`
--
ALTER TABLE `busness`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `busness`
--
ALTER TABLE `busness`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
