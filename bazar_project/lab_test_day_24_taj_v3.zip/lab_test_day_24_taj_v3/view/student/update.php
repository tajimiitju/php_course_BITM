<?php
include_once '../../vendor/autoload.php';
$student = new App\Student\Student();

if(!empty($_FILES['image']['name'])){
    $student->image_delete($_POST['id']);
    $student->upload();
}

$student->set($_POST)->update();

