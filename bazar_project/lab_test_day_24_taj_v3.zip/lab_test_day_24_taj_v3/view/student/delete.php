<?php

include_once '../../vendor/autoload.php';
$student = new App\Student\Student();
$student->image_delete($_GET['id']);
$student = $student->delete($_GET['id']);

