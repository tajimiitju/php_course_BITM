<?php
include_once '../include/header.php';
include_once '../../vendor/autoload.php';
$student = new App\Student\Student();
$student = $student->view($_GET['id']);

?>


<?php
include_once '../include/header.php';

?>

    <div id="page-wrapper" style="min-height: 349px;">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Edit Product</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        Edit product information and update
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-8 col-md-offset-2">
                                <form role="form" action="view/student/update.php" enctype="multipart/form-data" method="POST">
                                    <div class="form-group">
                                        <label>Product Title</label>
                                        <input name="Product_title" value="<?php echo $student['Product_title']?>" class="form-control">
                                        <input type="hidden" name="id" value="<?php echo $student['id']?>" class="form-control">
                                    </div>
                                    <label>Product price</label>
                                    <input name="Product_price" value="<?php echo $student['Product_price']?>" class="form-control">
                                    <div class="form-group">
                                        <label>Category</label>
                                        <select name="Category" class="form-control">
                                            <option>Select One</option>
                                            <option <?php echo ($student['Category']=='Male')?'selected':'' ?> value="Male">Male</option>
                                            <option <?php echo ($student['Category']=='Female')?'selected':'' ?> value="Female">Female</option>
                                            <option <?php echo ($student['Category']=='Baby')?'selected':'' ?> value="Baby">Baby</option>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Description</label>
                                        <textarea name="Description" class="form-control" rows="3"><?php echo $student['Description']?></textarea>
                                    </div>
                                    <div class="form-group">
                                    <label>Update Image</label>
                                        
                                    <input id="image" type="file" name="image" class="btn btn-default" value="view/uploads/<?= $student['image']?> />
                                    </div>
                                <div style="padding-bottom: 25px">
                                <img width="100" src="view/uploads/<?= $student['image']?>" alt="">
                                </div>
                                <button type="reset" class="btn btn-default">Reset Button</button>
                                <button type="submit" class="btn btn-warning">Update</button>
                                
                                </form>
                            </div>
                        </div>
                        <!-- /.row (nested) -->
                    </div>
                    <!-- /.panel-body -->
                </div>
                <!-- /.panel -->
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>

<?php
include_once '../include/footer.php';
?>


