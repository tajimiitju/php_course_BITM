<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD</title>
 <!--   <link rel="stylesheet" href="css/bootstrap.min.css">-->
    <link rel="stylesheet" href="css/mystyle.css">
</head>
<body>

<?php
    spl_autoload_register(function($class){
        include "class/". $class .".php";
    });
?>


<section class="header">
    <div class="headertitle">This is CRUD Project </div>
    <div class="createnew"><a href="index.php">CREATE NEW</a></div>
    <hr>
</section>
<section class="mainleft">
    <?php
    $user = new Student();
    if(isset($_POST['create'])){
        $name = $_POST['name'];
        $dept = $_POST['dept'];
        $age = $_POST['age'];

        $user->setName($name);
        $user->setDept($dept);
        $user->setAge($age);

        if($user->insert()){
            echo "<span class='insert'>Data Successfully Inserted</span>";

        }
    }
    if(isset($_POST['update'])){
        $id = $_POST['id'];
        $name = $_POST['name'];
        $dept = $_POST['dept'];
        $age = $_POST['age'];

        $user->setName($name);
        $user->setDept($dept);
        $user->setAge($age);

        if($user->update($id)){
            echo "<span class='update'>Data Successfully Updated</span>";

        }
    }

    ?>
    <?php
    if(isset($_GET['action']) && $_GET['action']=='delete') {
        $id = $_GET['id'];
        if($user->delete($id)){
            echo "<span class='delete'>Data Successfully Deleted</span>";

        }
    }
    ?>
    <?php
    if(isset($_GET['action']) && $_GET['action']=='update'){
        $id = $_GET['id'];
       $result = $user->readById($id);
    ?>

    <form action="" method="post">
        <table>
            <input type="hidden"  name="id" value="<?php echo $result['id']; ?>">
            <tr>
                <td>Name: </td>
                <td><input type="text" name="name" value="<?php echo $result['name']; ?>"></td>
            </tr>
            <tr>
                <td>Department: </td>
                <td><input type="text" name="dept" value="<?php echo $result['dept']; ?>"></td>
            </tr>
            <tr>
                <td>Age: </td>
                <td><input type="number" name="age" value="<?php echo $result['age']; ?>" ></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" class="btn-primary btn btn-rounded" name="update" value="UPDATE"></td>
            </tr>
        </table>
    </form>
    <?php } else { ?>
    <form action="" method="post">
        <table>
            <tr>
                <td>Name: </td>
                <td><input type="text" name="name" placeholder="Your Name" required></td>
            </tr>
            <tr>
                <td>Department: </td>
                <td><input type="text" name="dept" placeholder="Your Department" required></td>
            </tr>
            <tr>
                <td>Age: </td>
                <td><input type="number" name="age" placeholder="Your Age" required></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" class="btn-primary btn btn-rounded" name="create" value="INSERT"></td>
            </tr>
        </table>
    </form>
    <?php } ?>
</section>


<section class="mainright">
    <table class="tableone">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Department:</th>
            <th>Age</th>
            <th>Action</th>
        </tr>
    <?php
    $i = 0;
        foreach($user->readAll() as $key => $value){
            $i++;


     ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $value['name']; ?></td>
            <td><?php echo $value['dept']; ?></td>
            <td><?php echo $value['age']; ?></td>
            <td>
                <?php echo "<a href='index.php?action=update&id=".$value['id']."'>Edit</a>" ?> ||
                <?php echo "<a href='index.php?action=delete&id=".$value['id']."' onclick='return confirm(\"Are you  want to delete this data??\")'>Delete</a>" ?>

            </td>
        </tr>
    <?php } ?>
    </table>
</section>




<script src="js/jquery-3.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/myscript.js"></script>
</body>
</html>