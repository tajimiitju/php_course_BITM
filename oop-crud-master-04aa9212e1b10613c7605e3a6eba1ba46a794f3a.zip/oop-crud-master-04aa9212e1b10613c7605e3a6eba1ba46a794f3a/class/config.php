<?php
define('DB_HOST','localhost');
define('DB_NAME','db_student');
define('DB_USER','sumon');
define('DB_PASS','sumoncse');