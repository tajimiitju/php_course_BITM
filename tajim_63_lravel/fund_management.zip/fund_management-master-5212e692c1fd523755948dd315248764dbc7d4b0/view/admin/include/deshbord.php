<div class="right_col" role="main">
    <!-- top tiles -->
    <div class="row tile_count">
        <div class="right_col" role="main">
        </div>
    </div>
</div>