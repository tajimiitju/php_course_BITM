</div>
</div>
<!-- footer content -->
<footer>
    <div class="pull-right">
        Copywrite &copy 2017 By <a href="https://colorlib.com">Team HackSlash</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->
<!-- jQuery -->
<script src="assets/admin/vendors/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="assets/admin/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Custom Theme Scripts -->
<script src="assets/admin/build/js/custom.min.js"></script>
<!-- My Custom Scripts -->
<script src="assets/admin/js/main.js"></script>

</body>

</html>