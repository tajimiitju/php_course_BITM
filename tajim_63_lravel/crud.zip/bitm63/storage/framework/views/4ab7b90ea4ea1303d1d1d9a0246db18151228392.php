<?php
    echo "This is ".$name." user number ".$id;
?>
<br>


<?php echo e("This is ".$name." user number ".$id); ?>



